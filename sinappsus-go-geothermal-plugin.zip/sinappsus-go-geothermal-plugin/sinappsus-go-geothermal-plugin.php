<?php
/*
 * Plugin Name: Sinappsus GoGeothermal Official Plugin
 * Description: A custom WordPress plugin to integrate WooCommerce with The Go Geothermal API.
 * Plugin URI: https://gogeothermal.co.uk
 * Author URI: https://sinappsus.agency
 * Version: 0.3.4
 * Author: Sinappsus
 * Requires at least: 5.0
 * Tested up to: 6.8
*/

defined('ABSPATH') || exit;

define('GGT_SINAPPSUS_PLUGIN_VERSION', '0.3.4');
define('GGT_SINAPPSUS_PLUGIN_URL', untrailingslashit(plugins_url(basename(plugin_dir_path(__FILE__)), basename(__FILE__))));
define('GGT_SINAPPSUS_PLUGIN_PATH', plugin_dir_path(__FILE__));

// Load Constants globally
require_once GGT_SINAPPSUS_PLUGIN_PATH . '/const.php';

// Plugin update checker
require_once GGT_SINAPPSUS_PLUGIN_PATH . '/plugin-update/plugin-update-checker.php';
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
    'https://raw.githubusercontent.com/Go-GeoThermal/wordpress-gogeothermal-plugin/refs/heads/master/sinappsus-go-geothermal-plugin/info.json',  
    __FILE__, 
    'ena-sinappsus-plugin'
);

// Activation check logic
function ggt_activation_check() {
    if (!class_exists('WooCommerce')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(__('This plugin requires WooCommerce to be installed and active.', 'sinappsus-ggt-wp-plugin'));
    }
}
register_activation_hook(__FILE__, 'ggt_activation_check');

// Check Plugin is activated or activate
function ggt_sinappsus_plugin()
{
    // Runtime check
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function() {
            $class = 'notice notice-error';
            $message = __('Sinappsus GoGeothermal Plugin requires WooCommerce to be installed and active.', 'sinappsus-ggt-wp-plugin');
            printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), esc_html($message));
        });
        return;
    }

    require_once(plugin_basename('includes/sinappsus-ggt-wp-plugin.php'));
    load_plugin_textdomain('sinappsus-ggt-wp-plugin', false, trailingslashit(dirname(plugin_basename(__FILE__))));

    // Load The Go Geothermal Admin UI
    require_once GGT_SINAPPSUS_PLUGIN_PATH . '/admin/ui.php';

    // Load Flexible Import functionality
    require_once GGT_SINAPPSUS_PLUGIN_PATH . '/admin/flexible-import.php';

    // Load User/Accounts Mapping functionality
    require_once GGT_SINAPPSUS_PLUGIN_PATH . '/admin/user-mapping.php';

    // Load Custom Product Tab for mapped fields
    require_once GGT_SINAPPSUS_PLUGIN_PATH . '/includes/product-tab.php';

    // Load Product Columns customization
    require_once GGT_SINAPPSUS_PLUGIN_PATH . '/includes/product-columns.php';
}

add_action('plugins_loaded', 'ggt_sinappsus_plugin', 0);

// Add settings link on plugin page
function ggt_sinappsus_plugin_action_links($links)
{
    $settings_link = '<a href="admin.php?page=sinappsus-ggt-settings">' . __('Settings', 'sinappsus-ggt-wp-plugin') . '</a>';
    $payment_link = '<a href="admin.php?page=wc-settings&tab=checkout&section=geo_credit">' . __('Payment Configuration', 'sinappsus-ggt-wp-plugin') . '</a>';
    array_unshift($links, $settings_link, $payment_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'ggt_sinappsus_plugin_action_links');

