<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class WC_Geo_Credit_Gateway extends WC_Payment_Gateway {
    public function __construct() {
        $this->id = 'geo_credit';
        $this->title = __('Go Geothermal Credit Payment', 'woocommerce');
        $this->description = __('Use your available credit to checkout.', 'woocommerce');
        $this->has_fields = false;
        $this->method_title = __('Go Geothermal Credit Payment', 'woocommerce');
        $this->method_description = __('Allows Go geothermal credit approved users to pay with credit if their credit limit is sufficient.', 'woocommerce');

        $this->init_form_fields();
        $this->init_settings();

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

        // Add support for blocks checkout
        $this->add_blocks_support();
    }

    // Add support for WooCommerce Blocks
    private function add_blocks_support() {
        // Check if WC Blocks is active and of a compatible version
        if (class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
            require_once GGT_SINAPPSUS_PLUGIN_PATH . '/includes/blocks/class-wc-geo-credit-blocks.php';
            // $this->logger->info('WooCommerce Blocks support classes loaded: ' . GGT_SINAPPSUS_PLUGIN_PATH . '/includes/blocks/class-wc-geo-credit-blocks.php');
        }
    }

    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title' => __('Enable/Disable', 'woocommerce'),
                'type' => 'checkbox',
                'label' => __('Enable Credit Payment', 'woocommerce'),
                'default' => 'yes'
            ),
            'debug' => array(
                'title' => __('Debug Mode', 'woocommerce'),
                'type' => 'checkbox',
                'label' => __('Enable debug mode', 'woocommerce'),
                'default' => 'yes',
                'description' => __('Show debug info on checkout page', 'woocommerce'),
            )
        );
    }

    public function is_available() {
        // First, check if the gateway is enabled
        if ($this->enabled != 'yes') {
            return false;
        }

        // Check if user is logged in
        if (!is_user_logged_in()) {
            return false;
        }

        $user_id = get_current_user_id();
        $cart_total = WC()->cart->total;

        // Try different meta keys where credit limit might be stored
        $credit_limit = get_user_meta($user_id, 'creditLimit', true);
        if (empty($credit_limit)) {
            // Check legacy key just in case, but prefer creditLimit
            $credit_limit = get_user_meta($user_id, 'CreditLimit', true);
        }
        if (empty($credit_limit)) {
            $credit_limit = get_user_meta($user_id, 'credit_limit', true);
        }

        // Get current balance
        $balance = get_user_meta($user_id, 'Balance', true);
        if (empty($balance)) {
            $balance = get_user_meta($user_id, 'balance', true);
        }
        // Default balance to 0 if not set
        if (empty($balance)) {
            $balance = 0;
        }

        // Calculate available credit
        $available_credit = floatval($credit_limit) - floatval($balance);

        if (empty($credit_limit) || $available_credit < floatval($cart_total)) {
            return false;
        }

        return true;
    }

    public function process_payment($order_id) {
        $order = wc_get_order($order_id);
        $user_id = $order->get_user_id();
        // Store payment provider meta for consistency
        $order->update_meta_data('ggt_payment_method', $order->get_payment_method());
        $order->update_meta_data('ggt_payment_method_title', $order->get_payment_method_title());
        $order->save();

        // Comprehensive check for delivery date from multiple sources
        $delivery_date = null;
        
        $delivery_date = get_post_meta($order_id, 'ggt_delivery_date', true);
        
        // Check POST data if no date found in meta
        if (empty($delivery_date)) {
            if (!empty($_POST['ggt_delivery_date'])) {
                $delivery_date = sanitize_text_field($_POST['ggt_delivery_date']);
            } elseif (!empty($_POST['ggt_delivery_date_hidden'])) {
                $delivery_date = sanitize_text_field($_POST['ggt_delivery_date_hidden']);
            }
            
            // If found in POST, save it to canonical meta key
            if (!empty($delivery_date)) {
                update_post_meta($order_id, 'ggt_delivery_date', $delivery_date);
            }
        }
        
        // Also check session as last resort
        if (empty($delivery_date) && WC()->session && WC()->session->get('ggt_validated_delivery_date')) {
            $delivery_date = WC()->session->get('ggt_validated_delivery_date');
            update_post_meta($order_id, 'ggt_delivery_date', $delivery_date);
        }

        // Try different meta keys where credit limit might be stored
        $credit_limit = get_user_meta($user_id, 'CreditLimit', true);
        if (empty($credit_limit)) {
            $credit_limit = get_user_meta($user_id, 'creditLimit', true);
        }
        if (empty($credit_limit)) {
            $credit_limit = get_user_meta($user_id, 'credit_limit', true);
        }

        // Get current balance
        $balance = get_user_meta($user_id, 'Balance', true);
        if (empty($balance)) {
            $balance = get_user_meta($user_id, 'balance', true);
        }
        // Default balance to 0 if not set
        if (empty($balance)) {
            $balance = 0;
        }

        // Calculate available credit
        $available_credit = floatval($credit_limit) - floatval($balance);

        if (!empty($credit_limit) && $available_credit >= floatval($order->get_total())) {
            
            // 1. Send order details to external API FIRST
            $response = $this->send_order_to_api($order, $delivery_date);

            if (is_wp_error($response)) {
                $error_msg = $response->get_error_message();
                wc_get_logger()->error('GGT Credit Payment Transport Error: ' . $error_msg);
                wc_add_notice(__('Communication failed with the order system. Please try again.', 'woocommerce'), 'error');
                return array('result' => 'fail');
            }

            $response_code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);

            // 2. Check for Success (200-299)
            if ($response_code >= 200 && $response_code < 300) {
                $updated_balance = floatval($balance) + floatval($order->get_total());
                $this->update_account_ref_balances($user_id, $updated_balance);

                // Mark order as completed
                $order->payment_complete();
                $order->update_status('completed', __('Paid using store credit.', 'woocommerce'));
                // Mark sent to avoid duplicate sends by global hooks
                $order->update_meta_data('ggt_sales_order_sent', 1);
                $order->update_meta_data('ggt_sales_order_sent_at', current_time('mysql'));
                $order->save();

                return array(
                    'result'   => 'success',
                    'redirect' => $this->get_return_url($order)
                );
            } 
            // 3. Handle Errors
            elseif ($response_code == 401) {
                // Handle Authorization Failure
                $msg = __('Authorization failure.', 'woocommerce');
                
                // Check for specific "User is not approved" message
                if (isset($data['message']) && strpos($data['message'], 'User is not approved') !== false) {
                    // Handle the specific error: flag order, notify admin
                    if (function_exists('ggt_handle_account_not_found_error')) {
                        ggt_handle_account_not_found_error($order);
                    }
                    
                    // Treat as success for the user flow (transaction logged), but order is on-hold
                    // We empty cart and redirect to thank you page where the notice will be shown
                    WC()->cart->empty_cart();
                    
                    return array(
                        'result'   => 'success',
                        'redirect' => $this->get_return_url($order)
                    );
                } 
                
                if(isset($data['message'])) {
                     $msg .= ' ' . $data['message'];
                }
                
                wc_add_notice($msg, 'error');
                return array('result' => 'fail');
            } else {
                // 4. Handle Validation (422) or Server Error (500)
                $error_msg = __('Unable to process order.', 'woocommerce');
                
                // Parse standard Laravel "errors" object: { "field": ["error1", "error2"] }
                // Or the specific structure provided: {"errors":{"Illuminate\\Support\\MessageBag":{"items":["The items field is required."]}}}
                
                if (!empty($data['errors'])) {
                    $details = [];
                    
                    // Recursive function to flatten error array
                    $flatten_errors = function($array) use (&$flatten_errors) {
                        $flat = [];
                        foreach ($array as $key => $value) {
                            if (is_array($value)) {
                                $flat = array_merge($flat, $flatten_errors($value));
                            } else {
                                $flat[] = $value;
                            }
                        }
                        return $flat;
                    };

                    $flat_errors = $flatten_errors($data['errors']);
                    if (!empty($flat_errors)) {
                         $error_msg .= ' Details: ' . implode(' ', $flat_errors);
                    }
                } elseif (!empty($data['message'])) {
                    $error_msg .= ' ' . $data['message'];
                }

                wc_get_logger()->error('GGT Credit Payment Rejected (Code '.$response_code.'): ' . $error_msg);
                wc_add_notice($error_msg, 'error');
                return array('result' => 'fail');
            }
        } else {
            wc_add_notice(__('Insufficient credit balance.', 'woocommerce'), 'error');
            return array('result' => 'fail');
        }
    }

    private function send_order_to_api($order, $delivery_date) {
        $api_key = $this->get_token(); // Calls internal helper which uses ggt_get_decrypted_token
        $api_base_url = ggt_get_api_base_url();
        $endpoint = $api_base_url . '/sales-orders/wp-new-order';

        $user_id = $order->get_user_id();
        $user_meta = get_user_meta($user_id);
        
        // Read delivery date from canonical meta key
        $delivery_date = $order->get_meta('ggt_delivery_date', true);
        if (empty($delivery_date)) {
            $delivery_date = get_post_meta($order->get_id(), 'ggt_delivery_date', true);
        }

        $formatted_delivery_date = $delivery_date ? date('Y-m-d', strtotime($delivery_date)) : null;
        
        // Look for delivery address information
        $delivery_address = null;
        $delivery_address_json = $order->get_meta('ggt_delivery_info');
        if (!empty($delivery_address_json)) {
            $delivery_address_data = json_decode(stripslashes($delivery_address_json), true);
            if ($delivery_address_data && isset($delivery_address_data['original'])) {
                $delivery_address = $delivery_address_data['original'];
            }
        }
        
        $order_data = array(
            'woocommerce_order_id' => $order->get_id(),
            'user_id'        => $user_id,
            'total'          => $order->get_total(),
            'currency'       => get_woocommerce_currency(),
            'billing'        => $order->get_address('billing'),
            'shipping'       => $order->get_address('shipping'),
            'user_meta'      => $user_meta,
            'items'          => array(),
            'world_pay'      => $order->get_payment_method(),
            'payment_provider' => $order->get_payment_method(),
            'payment_provider_title' => $order->get_payment_method_title(),
            'delivery_date'  => $formatted_delivery_date,
            'delivery_address' => $delivery_address,
            'customer_note'  => $order->get_customer_note(),
        );
        
        foreach ($order->get_items() as $item_id => $item) {
            $product = $item->get_product();
            $stock_code = get_post_meta($product->get_id(), '_stockCode', true); // Fetch the stock code
            
            // Calculate unit price (total item price divided by quantity)
            $quantity = $item->get_quantity();
            $total_price = $item->get_total();
            $unit_price = $quantity > 0 ? ($total_price / $quantity) : 0;

            $order_data['items'][] = array(
                'product_id' => $product->get_id(),
                'name'       => $product->get_name(),
                'quantity'   => $quantity,
                'unitPrice'  => round($unit_price, 2), // Unit price per item
                'price'      => $total_price, // Total price for all items of this type
                'stock_code' => $stock_code, // Include the stock code
            );
        }

        // Log the API request
        ggt_log_api_interaction('Credit payment API request', 'info', [
            'endpoint' => $endpoint,
            'method' => 'POST', 
            'payload' => $order_data
        ]);

        $response = wp_remote_post($endpoint, array(
            'method'    => 'POST',
            'timeout'   => 300,
            'headers'   => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ),
            'body'      => json_encode($order_data),
        ));

        // Log the response
        if (is_wp_error($response)) {
            ggt_log_api_interaction('Credit payment API response error', 'error', [
                'endpoint' => $endpoint,
                'error' => $response->get_error_message()
            ]);
        } else {
            $code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);
            $body_data = json_decode($body, true);
            
            ggt_log_api_interaction('Credit payment API response', 'info', [
                'endpoint' => $endpoint,
                'status' => $code,
                'response' => $body_data ?: $body
            ]);
        }

        return $response;
    }

    /**
     * Update the shared balance for every WP user on the same accountRef.
     */
    private function update_account_ref_balances($user_id, $new_balance) {
        $related_user_ids = $this->get_account_ref_user_ids($user_id);

        foreach ($related_user_ids as $related_user_id) {
            $balance_key = 'balance';
            if (get_user_meta($related_user_id, 'Balance', true) !== '') {
                $balance_key = 'Balance';
            } else if (get_user_meta($related_user_id, 'balance', true) !== '') {
                $balance_key = 'balance';
            }

            update_user_meta($related_user_id, $balance_key, $new_balance);
        }
    }

    /**
     * Get all WP user IDs that share the current user's accountRef.
     */
    private function get_account_ref_user_ids($user_id) {
        $user_ids = array(intval($user_id));
        $account_ref = get_user_meta($user_id, 'accountRef', true);

        if (empty($account_ref)) {
            return $user_ids;
        }

        $matching_user_ids = get_users(array(
            'fields'     => 'ids',
            'meta_key'   => 'accountRef',
            'meta_value' => $account_ref,
            'number'     => -1,
        ));

        if (!empty($matching_user_ids)) {
            $user_ids = array_merge($user_ids, array_map('intval', $matching_user_ids));
        }

        return array_values(array_unique($user_ids));
    }

    private function get_token()
    {
        return function_exists('ggt_get_decrypted_token') ? ggt_get_decrypted_token() : false;
    }
}

// Register the gateway with WooCommerce
function add_geo_credit_gateway($methods) {
    $methods[] = 'WC_Geo_Credit_Gateway';
    return $methods;
}
add_filter('woocommerce_payment_gateways', 'add_geo_credit_gateway');

// Initialize the gateway
new WC_Geo_Credit_Gateway();